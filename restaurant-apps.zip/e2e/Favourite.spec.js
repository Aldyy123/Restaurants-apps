Feature('Favourite Restaurant')

Scenario('Empty Favourite', ({ I }) => {
  I.amOnPage('/#/favorite')
  I.seeElement('#favorite')
  I.see('', '#favorite')
})
Scenario('Add Into Favourite and delete from Favourite', ({ I }) => {
  I.amOnPage('/')
  I.seeElement('#list .link-resto')
  I.click(locate('#list .link-resto').first())
  I.seeElement('#floating #like')
  I.click('#like')
  I.amOnPage('/#/favorite')
  I.seeElement('#favorite .link-resto')
  I.click(locate('#favorite .link-resto').first())
  I.seeElement('#floating #liked')
  I.click('#liked')
})
